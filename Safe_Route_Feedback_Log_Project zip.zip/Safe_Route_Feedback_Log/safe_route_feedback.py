"""
SAFE ROUTE FEEDBACK LOG
Project #76 - Python for Good
Python 3.10+ | Standard library only

Run:
    python safe_route_feedback.py

The program stores records in safe_route_feedback.json beside this file.
It can also export CSV, Markdown and text reports.
"""

import csv
import json
import os
from collections import Counter
from datetime import date, datetime
from statistics import mean

DATA_FILE = "safe_route_feedback.json"
DATE_FORMAT = "%Y-%m-%d"

CATEGORIES = [
    "Poor lighting",
    "Pothole / damaged road",
    "Unsafe crossing",
    "Harassment",
    "Traffic danger",
    "Stray animals",
    "Blocked footpath",
    "Other",
]
STATUSES = ["Open", "In Progress", "Resolved"]
SEVERITIES = {1: "Low", 2: "Moderate", 3: "High", 4: "Critical", 5: "Emergency"}

FIELDS = [
    "id", "route", "location", "category", "severity", "description",
    "reporter", "reported_on", "status", "deadline"
]


def load_records():
    """Load saved records. Recover safely if the file is missing or damaged."""
    if not os.path.exists(DATA_FILE):
        return []
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as file:
            data = json.load(file)
        if not isinstance(data, list):
            raise ValueError("The JSON file must contain a list of records.")
        valid = []
        for item in data:
            if isinstance(item, dict) and all(field in item for field in FIELDS):
                valid.append(item)
        return valid
    except (json.JSONDecodeError, OSError, ValueError) as error:
        print(f"\nWarning: Could not read saved data ({error}).")
        print("Starting with an empty record list. The old file is not overwritten yet.")
        return []


def save_records(records):
    """Save safely using a temporary file, then replace the old file."""
    temp_file = DATA_FILE + ".tmp"
    with open(temp_file, "w", encoding="utf-8") as file:
        json.dump(records, file, indent=4, ensure_ascii=False)
    os.replace(temp_file, DATA_FILE)


def ask_text(prompt, min_length=1, max_length=200):
    while True:
        value = input(prompt).strip()
        if len(value) < min_length:
            print("This field cannot be blank.")
        elif len(value) > max_length:
            print(f"Please enter no more than {max_length} characters.")
        else:
            return value


def ask_choice(prompt, choices):
    print()
    for number, choice in enumerate(choices, 1):
        print(f"  {number}. {choice}")
    while True:
        value = input(prompt).strip()
        try:
            number = int(value)
            if 1 <= number <= len(choices):
                return choices[number - 1]
        except ValueError:
            pass
        print(f"Enter a number from 1 to {len(choices)}.")


def ask_severity():
    print("\nSeverity:")
    for number, label in SEVERITIES.items():
        print(f"  {number}. {label}")
    while True:
        try:
            value = int(input("Choose severity (1-5): ").strip())
            if value in SEVERITIES:
                return value
        except ValueError:
            pass
        print("Enter a whole number from 1 to 5.")


def ask_date(prompt, allow_blank=False):
    while True:
        value = input(prompt).strip()
        if allow_blank and not value:
            return ""
        try:
            parsed = datetime.strptime(value, DATE_FORMAT).date()
            return parsed.isoformat()
        except ValueError:
            print("Enter a valid date in YYYY-MM-DD format.")


def next_id(records):
    existing = []
    for record in records:
        try:
            existing.append(int(record["id"]))
        except (ValueError, TypeError, KeyError):
            continue
    return str(max(existing, default=0) + 1)


def add_record(records):
    print("\n--- Add Route Safety Feedback ---")
    record = {
        "id": next_id(records),
        "route": ask_text("Route name (e.g. Main Gate to Hostel): ", 2, 100),
        "location": ask_text("Exact location / landmark: ", 2, 150),
        "category": ask_choice("Select concern category:", CATEGORIES),
        "severity": ask_severity(),
        "description": ask_text("Describe the issue: ", 5, 500),
        "reporter": ask_text("Reporter name (or Anonymous): ", 1, 80),
        "reported_on": date.today().isoformat(),
        "status": "Open",
        "deadline": ask_date("Target resolution date YYYY-MM-DD (optional, Enter to skip): ", True),
    }
    records.append(record)
    save_records(records)
    print(f"\nFeedback saved successfully. Record ID: {record['id']}")


def print_records(records):
    if not records:
        print("\nNo matching records found.")
        return
    print("\n" + "-" * 112)
    print(f"{'ID':<5} {'ROUTE':<23} {'CATEGORY':<24} {'SEV.':<5} {'STATUS':<13} {'REPORTED':<12} {'LOCATION'}")
    print("-" * 112)
    for r in records:
        print(
            f"{str(r['id']):<5} {r['route'][:22]:<23} {r['category'][:23]:<24} "
            f"{r['severity']:<5} {r['status'][:12]:<13} {r['reported_on']:<12} "
            f"{r['location'][:28]}"
        )
    print("-" * 112)
    print(f"Total records shown: {len(records)}")


def search_records(records):
    print("\n--- Search / Filter Feedback ---")
    keyword = input("Enter keyword (route, location, description, reporter; Enter for any): ").strip().lower()
    category = input("Filter category (Enter for any): ").strip().lower()
    status = input("Filter status: Open / In Progress / Resolved (Enter for any): ").strip().lower()

    results = []
    for r in records:
        searchable = " ".join(str(r.get(k, "")) for k in
                              ("route", "location", "description", "reporter", "category")).lower()
        if keyword and keyword not in searchable:
            continue
        if category and category not in r["category"].lower():
            continue
        if status and status != r["status"].lower():
            continue
        results.append(r)
    print_records(results)


def update_status(records):
    record_id = input("\nEnter the ID to update: ").strip()
    record = next((r for r in records if str(r["id"]) == record_id), None)
    if not record:
        print("Record ID not found.")
        return
    print(f"Current status: {record['status']}")
    record["status"] = ask_choice("Choose new status:", STATUSES)
    save_records(records)
    print("Status updated and saved.")


def is_overdue(record):
    if not record.get("deadline") or record["status"] == "Resolved":
        return False
    try:
        return datetime.strptime(record["deadline"], DATE_FORMAT).date() < date.today()
    except ValueError:
        return False


def show_summary(records):
    print("\n========== EXECUTIVE SUMMARY ==========")
    total = len(records)
    if total == 0:
        print("No feedback records available yet.")
        return

    status_counts = Counter(r["status"] for r in records)
    category_counts = Counter(r["category"] for r in records)
    overdue = [r for r in records if is_overdue(r)]
    average_severity = mean(int(r["severity"]) for r in records)

    print(f"Total feedback reports : {total}")
    print(f"Average severity       : {average_severity:.2f} / 5")
    print(f"Open                  : {status_counts.get('Open', 0)}")
    print(f"In Progress           : {status_counts.get('In Progress', 0)}")
    print(f"Resolved              : {status_counts.get('Resolved', 0)}")
    print(f"Overdue unresolved    : {len(overdue)}")
    print("\nReports by category:")
    for category, count in category_counts.most_common():
        print(f"  {category:<28} {count}")
    critical = [r for r in records if int(r["severity"]) >= 4 and r["status"] != "Resolved"]
    print("\nPriority warnings:")
    if overdue:
        print(f"  WARNING: {len(overdue)} unresolved report(s) passed their deadline.")
    if critical:
        print(f"  WARNING: {len(critical)} unresolved high/critical/emergency report(s).")
    if not overdue and not critical:
        print("  No overdue or high-priority unresolved reports.")
    print("=======================================")


def export_csv(records, filename="safe_route_feedback_export.csv"):
    with open(filename, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(records)
    print(f"CSV report exported: {filename}")


def export_text_report(records, filename="safe_route_summary.txt"):
    lines = [
        "SAFE ROUTE FEEDBACK LOG - SUMMARY",
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"Total records: {len(records)}",
        f"Open: {sum(r['status'] == 'Open' for r in records)}",
        f"In Progress: {sum(r['status'] == 'In Progress' for r in records)}",
        f"Resolved: {sum(r['status'] == 'Resolved' for r in records)}",
        f"Overdue unresolved: {sum(is_overdue(r) for r in records)}",
        "",
        "RECORD DETAILS",
    ]
    for r in records:
        lines.append(
            f"ID {r['id']} | {r['route']} | {r['location']} | {r['category']} | "
            f"Severity {r['severity']} | {r['status']} | {r['description']}"
        )
    with open(filename, "w", encoding="utf-8") as file:
        file.write("\n".join(lines))
    print(f"Text report exported: {filename}")


def export_markdown(records, filename="safe_route_summary.md"):
    lines = [
        "# Safe Route Feedback Log",
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        f"- **Total reports:** {len(records)}",
        f"- **Open:** {sum(r['status'] == 'Open' for r in records)}",
        f"- **In Progress:** {sum(r['status'] == 'In Progress' for r in records)}",
        f"- **Resolved:** {sum(r['status'] == 'Resolved' for r in records)}",
        f"- **Overdue unresolved:** {sum(is_overdue(r) for r in records)}",
        "",
        "| ID | Route | Location | Category | Severity | Status |",
        "|---|---|---|---|---:|---|",
    ]
    for r in records:
        safe = lambda value: str(value).replace("|", "\\|").replace("\n", " ")
        lines.append(
            f"| {safe(r['id'])} | {safe(r['route'])} | {safe(r['location'])} | "
            f"{safe(r['category'])} | {r['severity']} | {safe(r['status'])} |"
        )
    with open(filename, "w", encoding="utf-8") as file:
        file.write("\n".join(lines))
    print(f"Markdown report exported: {filename}")


def import_csv(records):
    filename = input("Enter CSV file path: ").strip().strip('"')
    if not os.path.isfile(filename):
        print("File not found.")
        return
    added = 0
    errors = []
    try:
        with open(filename, "r", newline="", encoding="utf-8-sig") as file:
            reader = csv.DictReader(file)
            required = set(FIELDS) - {"id"}
            if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
                print("CSV must contain these columns: " + ", ".join(sorted(required)))
                return
            for row_number, row in enumerate(reader, start=2):
                try:
                    severity = int(row["severity"])
                    if severity not in SEVERITIES:
                        raise ValueError("severity must be 1 to 5")
                    category = row["category"].strip()
                    if category not in CATEGORIES:
                        raise ValueError("unknown category")
                    status = row["status"].strip()
                    if status not in STATUSES:
                        raise ValueError("unknown status")
                    reported = datetime.strptime(row["reported_on"].strip(), DATE_FORMAT).date()
                    deadline_text = row.get("deadline", "").strip()
                    if deadline_text:
                        datetime.strptime(deadline_text, DATE_FORMAT)
                    record = {
                        "id": next_id(records),
                        "route": row["route"].strip(),
                        "location": row["location"].strip(),
                        "category": category,
                        "severity": severity,
                        "description": row["description"].strip(),
                        "reporter": row["reporter"].strip(),
                        "reported_on": reported.isoformat(),
                        "status": status,
                        "deadline": deadline_text,
                    }
                    if not all(record[k] for k in ("route", "location", "description", "reporter")):
                        raise ValueError("required text field is blank")
                    records.append(record)
                    added += 1
                except (ValueError, KeyError) as error:
                    errors.append(f"Row {row_number}: {error}")
        save_records(records)
        print(f"Imported {added} record(s).")
        if errors:
            print("Rows skipped due to errors:")
            for error in errors:
                print(" - " + error)
    except (OSError, csv.Error) as error:
        print(f"Could not import CSV: {error}")


def load_demo_data(records):
    """Add 30 varied sample records for a hackathon demonstration."""
    locations = [
        "Library Junction", "North Gate", "Hostel Road", "Bus Stop",
        "Sports Complex", "Main Road Crossing"
    ]
    descriptions = [
        "Street light is not working after sunset.",
        "Deep pothole creates a risk for cyclists.",
        "Vehicles do not stop at the pedestrian crossing.",
        "Footpath is blocked by parked vehicles.",
        "People reported an unsafe incident at this spot.",
    ]
    added = 0
    for i in range(30):
        severity = (i % 5) + 1
        record = {
            "id": next_id(records),
            "route": f"Route {chr(65 + (i % 6))}",
            "location": locations[i % len(locations)],
            "category": CATEGORIES[i % len(CATEGORIES)],
            "severity": severity,
            "description": descriptions[i % len(descriptions)],
            "reporter": "Demo User",
            "reported_on": date.today().isoformat(),
            "status": STATUSES[i % len(STATUSES)],
            "deadline": date.today().isoformat() if i % 7 == 0 else "",
        }
        records.append(record)
        added += 1
    save_records(records)
    print(f"Added {added} demo records. Total records: {len(records)}")


def main():
    records = load_records()
    print("=" * 54)
    print("          SAFE ROUTE FEEDBACK LOG")
    print("       Safer routes through community feedback")
    print("=" * 54)

    while True:
        print("""
MAIN MENU
1. Add new safety feedback
2. View all feedback
3. Search / filter feedback
4. Update feedback status
5. Executive summary and warnings
6. Export CSV report
7. Export text report
8. Export Markdown report
9. Import records from CSV
10. Add 30 demo records
0. Save and exit
""")
        choice = input("Enter your choice: ").strip()
        try:
            if choice == "1":
                add_record(records)
            elif choice == "2":
                print_records(records)
            elif choice == "3":
                search_records(records)
            elif choice == "4":
                update_status(records)
            elif choice == "5":
                show_summary(records)
            elif choice == "6":
                export_csv(records)
            elif choice == "7":
                export_text_report(records)
            elif choice == "8":
                export_markdown(records)
            elif choice == "9":
                import_csv(records)
            elif choice == "10":
                load_demo_data(records)
            elif choice == "0":
                save_records(records)
                print("All records saved. Thank you for helping make routes safer!")
                break
            else:
                print("Invalid menu option. Choose a number from 0 to 10.")
        except (OSError, csv.Error) as error:
            print(f"File operation error: {error}")
        except KeyboardInterrupt:
            print("\nOperation cancelled. Returning to the menu.")
        except Exception as error:
            # Last-resort protection so one unexpected input does not close the app.
            print(f"Unexpected error: {error}")


if __name__ == "__main__":
    main()
